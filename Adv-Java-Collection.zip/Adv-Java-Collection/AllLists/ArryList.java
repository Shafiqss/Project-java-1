package AllLists;

import java.util.*;

public class ArryList
{
    public static void main(String[] args)
    {
        ArryList<Object> sh= new ArryList();
        sh.add("shafiq");
        sh.add("shahwali");
        sh.add(1);
        sh.add(2);
        sh.add(1.5);
        sh.add('m');

        // important function in array list
        sh.remove(0); 

        System.out.println(" array List"+sh.size()); 
        
        System.out.println("index number 0: "+sh.get(0)); 
     
        System.out.println("is array list empty: "+sh.isEmpty());

        sh.set(2,"shafiqullah");
      
        Iterator<Object> itrr = sh.iterator();
        while(itrr.hasNext())
        {
            Object object = ittrr.next();
            System.out.println(object);
        }

    }
}
