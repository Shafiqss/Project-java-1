package allLists;

public class Student
{
    int id;
    String name;

    public Student(int id, String name,int age)
    {
        this.id = id;
        this.name = name;
        this.age=age;
    }

    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }
    public int getage()
    {
        return age;
    }
}
