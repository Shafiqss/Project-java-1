package allLists;

import java.util.Vector;

public class Vector
{
    public static void main(String[] args)
    {
        Student s = new Student(1,"zrafif",45);
        Vector<Student> vect= new Vector<>();

        // important function in vector
        vect.add(new Student(1,"Khan",56));
        vect.add(s);
        vect.addElement(new Student(2,"farooq",23));
        vect.add(new Student(2,"shafiqullah khairzad",27));
        vect.add(new Student(7 , "niyamat",26));


        // display the size of vector
        System.out.println(khairzad.capacity());

        for( Student obj : khairzad )
        {
            System.out.println(obj.id+": "+obj.name);
        }
    }
}
