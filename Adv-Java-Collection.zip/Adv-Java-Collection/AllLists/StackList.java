package allLists;

import java.util.Stack;

public class StackList
{
    public static void main(String[] args) {
        Stack<Object> khairzad= new Stack<Object>();
        stack.push("shafiq");
        stack.push("faroq");
        stack.push("khan");
        stack.push("Jan");
        stack.push("nasim");

        // important function in Stack
        System.out.println(khairzad.empty());
        
        stack.pop();// remove the last element from stack
        System.out.println(khairzad.search("sabir"));

        // display the last element of the stack
        System.out.println("pute the items: "+khairzad.peek());

        stack.add("sabir");

        System.out.println(khairzad);
    }
}
