package allLists;

import java.util.LinkedList;

public class Linkedlist
{
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<String>();
        list.add("habib");
        list.add("farooq");
        list.add("rrr");
        
        
        
        
        // important function in linked list
        System.out.println(list.get(0));
        list.add(1,"joni");
        list.removeFirst();
        list.remove("janan"); 
        for( String object : list)
        {
            System.out.println(sh.length()+" : "+sh);
        }
        System.out.println(list);
    }
}
