package AllMap;

import java.util.HashMap;

public class HashMap
{

    public static void main(String[] args) {
        // Creating an empty HashMap
       HashMap<String, String> sh1 = new HashMap<String, String>();
        
        lhm.put("one", "Java");
        lhm.put("two", "c++");
        lhm.put("four", "C Language");
        System.out.println(sh1);
        System.out.println("Getting value for key 'one': " +sh1.get("one"));

        // size() method
        System.out.println("Size of the map: " + sh1.size());

        // empty or not
        System.out.println("Is map empty? " +sh1.isEmpty());

        // Using containsKey() method to check for a key
        System.out.println("Contains key 'two'? " + sh1.containsKey("two"));

        // Using containsKey() method to check for a value
        System.out.println( sh1.containsValue("practice" + ".Python"));

        // Removing entry using remove() method
        System.out.println("delete element 'one': " + sh1.remove("one"));

        // Printing mappings to the console
        System.out.println("Mappings of HashMap : " +sh1);
    }
    }

