package AllMap;

import allLists.Student;

import java.util.HashMap;

public class HasheMape
{
    public static void main(String[] args) {
    	HasheMape InserthashMap= new HasheMape();
    	InserthashMap.put("Name", "shafiq");
    	InserthashMap.put("Father Name", "Adilshah");
    	InserthashMap.put("Last Name", "khairzad");
    	InserthashMap.put("Faculty", "Computer Science");
    	InserthashMap.put("Name", "HABIB");
    	InserthashMap.put("Father Name", "Adilshah");
    	InserthashMap.put("Last Name", "khairzad");
    	InserthashMap.put("Faculty", "LAW FACULTYe");


        hashMap.remove("Name"); // remove  key
        // is this hash map is empty
        System.out.println("Empty: "+InserthashMap.isEmpty());
        System.out.println(".-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.");
        if (!InserthashMap.isEmpty())
        {
            System.out.println("HashMap is not empty");

            // Accessing the contents of HashMap through Keys
            System.out.println("Name : " +InserthashMap.get("Name"));
            System.out.println("Father Name : " +InserthashMap.get("Father Name"));
            System.out.println("Faculty : " +InserthashMap.get("Faculty"));

            // size() method prints the size of HashMap.
            System.out.println("Size Of HashMap : " + InserthashMap.size());
        }
        System.out.println(InserthashMap.entrySet()); 
           }
}
