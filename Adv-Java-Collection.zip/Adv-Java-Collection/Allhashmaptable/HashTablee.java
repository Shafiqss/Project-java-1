package AllMap;

import java.util.Hashtable;

public class HashTable
{
    public static void main(String[] args) {

      
        Hashtable<Integer, String> sh1= new Hashtable<>();

        
        Hashtable<Integer, String> sh2 = new Hashtable<Integer, String>();

       
        sh1.put(1, "shafiq");
        sh1.put(2, "khan");
        sh1.put(3, "fROO");
        sh1.put(4, "TAHIR");
        sh2.put(4, "saboor");
        sh2.put(5, "farooq");
        sh2.put(6, "ATIQ");
        sh2.put(7, "RAHIM");
        System.out.println("Mappings of sh1 : " + sh1);
        System.out.println("Mappings of sh1 : " + sh1);
        System.out.println("Mappings of sh1 : " + sh1);
        System.out.println("Mappings of sh1 : " + sh1);
        System.out.println("Mappings of sh2 : " + sh2);
        System.out.println("Mappings of sh2 : " + sh2);
        System.out.println("Mappings of sh2 : " + sh2);
        System.out.println("Mappings of sh2 : " + sh2);
    }
    }
