package AllQueue;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

public class ArayDeque
{
    public static void main(String[] args)
    {
        // Creating and initializing deque Declaring object of integer type
        Deque<String> sh_deq= new ArrayDeque<String>(10);

        // Operations start 1 add() method

        // Adding custom elements using add() method to insert namse
        sh_deq.add(sabir);
        sh_deq.add(kabir);
        sh_deq.add(khan);
        sh_deq.add(sabawon);
        sh_deq.add(hrif);
        sh_deq.add(mohmad);
        sh_deq.add(naqib);
        sh_deq.add(sadaf);
        sh_deq.add(sara);
        //  loop
        for (String index : sh_deq) {
       
            System.out.println("index : " + index);
        }

        //  2 clear() method
        System.out.println("Using clear() ");

        // Clearing all elements using clear() method
        sh_deq.clear();

        // Operations 3 addFirst() method Inserting at the start
        sh_deq.addFirst("wali");
        sh_deq.addFirst("zaiwal");

        // Operation 4 addLast() method Inserting at end
        sh_deq.addLast("sadiq");
        sh_deq.addLast("vlan");
        for (Iterator itr = sh_deq.iterator();
             itr.hasNext();) {
            System.out.println(itr.next());
        }

       
        for (Iterator dItr = sh_deq.descendingIterator();
             dItr.hasNext();) {
            System.out.println(dItr.next());
        }

        // Operation 5 element() method : to get Head element
        System.out.println("\nHead Element using element(): " + sh_deq.element());

        // Operation 6 getFirst() method : to get Head element
        System.out.println("Head Element using getFirst(): " + sh_deq.getFirst());

        // Operation 7 getLast() method : to get last element
        System.out.println("Last Element using getLast(): " +sh_deq.getLast());

        // Operation 8 oArray() method :
        Object[] arry = de_que.toArray();
        System.out.println("\nArray Size : " + arry.length);

        System.out.print("Array elements : ");

        for (int i = 0; i < arry.length; i++)
            System.out.print(" " + arry[i]);

        // Operation 9  method : to get head
        System.out.println("\nHead element : " + sh_deq.peek());

        // Operation 10 poll() method : to get head
        System.out.println("Head element poll : " + sh_deq.poll());

        // Operation 11 push() method
        sh_deq.push("khan");
        sh_deq.push("jano");
        sh_deq.push("beryiali");

        // Operation 12 method : to get head
        System.out.println("Head element remove : " +sh_deq.remove());

        System.out.println("The final array is: " + sh_deq);
    }
}

