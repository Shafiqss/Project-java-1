package AllQueue;

import java.util.concurrent.ArrayBlockingQueue;

public class ArrayBlockingQueuee
{
    public static void main(String[] args) {
        int capacity = 10;
        ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(capacity);

        // Add element to ArrayBlockingQueue
        queue.add(3);
        queue.add(12);
        queue.add(95);
        queue.add(13);
        queue.add(24);
        queue.add(34);
        queue.add(34);
        queue.add(16);

        // Print queue after adding numbers
        System.out.println("After adding numbers queue is ");
        System.out.println(queue);
        boolean response = queue.remove(2);

        // print Queue
        System.out.println("Removal of 2 :" + response);

        // print Queue
        System.out.println("queue contains " + queue);

        // remove all the elements
        queue.clear();

        // print queue
        System.out.println("ArrayBlockingQueue:" + queue);

        // Print head of queue using peek() method
        System.out.println("top of queue " + queue.peek());
    }
}
