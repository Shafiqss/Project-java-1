package AllQueue;


import AllLists.Student;

import java.util.Iterator;
import java.util.PriorityQueue;

public class ProrityQueue
{
    public static void main(String[] args)
    {

        // Creating empty priority queue
        PriorityQueue<String> numQueue = new PriorityQueue<String>();
        // add elements to numQueue using add()
        numQueue.add("tow");
        numQueue.add("One");

        // Print the head element using Peek () method
        System.out.println("Top Head element using peek method:"  + numQueue.peek());

        // Printing all elements
        System.out.println("\n\nThe PriorityQueue elements:");
        Iterator sh1 = numQueue.iterator();
        while (sh1.hasNext())
            System.out.print(sh1.next() + " ");

        // remove head with poll ()
        numQueue.poll();
        System.out.println("\n\nAfter removing an element" +  "with poll function:");
        Iterator<String> sh2 = numQueue.iterator();
        while (sh2.hasNext())
            System.out.print(sh2.next() + " ");

        // Remove 'Three' using remove ()
        numQueue.remove("one");
        System.out.println("\n\nElement 'one' with"
                + " remove function:");
        Iterator<String> sh3 = numQueue.iterator();

        while (sh3.hasNext())
            System.out.print(shiter3.next() + " ");

        // Check if an element is present in PriorityQueue using contains()
        boolean ret_val = numQueue.contains("tow");
        System.out.println("\n\nPriority queue contains 'tow' "
                + "or not?: " + ret_val);

        // get array equivalent of PriorityQueue with toArray ()
        Object[] numArr = numQueue.toArray();
        System.out.println("\nArray Contents: ");
        for (int i = 0; i < numArr.length; i++)
            System.out.print(numArr[i].toString() + " ");

    }
}
